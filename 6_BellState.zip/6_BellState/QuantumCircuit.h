// This code is inspired by https://github.com/aman983/QEsp.

#ifndef QUANTUM_CIRCUIT_H
#define QUANTUM_CIRCUIT_H

#include <vector>
#include <string>
#include <cmath>
#include <complex> // CHANGED: Included for std::complex support
#include <Arduino.h>

class QuantumCircuit {
public:
    // CHANGED: Type aliases now use std::complex<double>
    using matrix = std::vector<std::vector<std::complex<double>>>;
    using vector_q = std::vector<std::vector<std::complex<double>>>;

    // Struct to hold the results of a measurement
    struct MeasurementResult {
        std::string basisState;
        double probability;
        int shots;
    };

    // Constructor: Initializes the circuit with a number of qubits
    QuantumCircuit(int num_qubits) : no_of_qubits(num_qubits) {
        // CHANGED: Definitions now use complex numbers
        I = {{{1, 0}, {0, 0}}, {{0, 0}, {1, 0}}};
        zero_vector = {{{1, 0}}, {{0, 0}}};

        // Initialize the unitary matrix and state vector for the multi-qubit system
        matrix initial_unitary = {{{1, 0}}};
        vector_q initial_state = {{{1, 0}}};

        for (int i = 0; i < no_of_qubits; ++i) {
            initial_unitary = tensorMatrix(initial_unitary, I);
            initial_state = tensorMatrix(initial_state, zero_vector);
        }
        unitary = initial_unitary;
        state_vector = initial_state;

        int num_basis_states = 1 << no_of_qubits;
        for (int i = 0; i < num_basis_states; ++i) {
            basis.push_back(basisState(i));
        }
    }

    // --- Quantum Gates ---

    void h(int qubit_index) {
        double sqrt2_inv = 1.0 / std::sqrt(2.0);
        matrix H_operator = {{sqrt2_inv, sqrt2_inv}, {sqrt2_inv, -sqrt2_inv}};
        applySingleQubitGate(H_operator, qubit_index);
    }

    void x(int qubit_index) {
        matrix X_operator = {{0, 1}, {1, 0}};
        applySingleQubitGate(X_operator, qubit_index);
    }

    void z(int qubit_index) {
        matrix Z_operator = {{1, 0}, {0, -1}};
        applySingleQubitGate(Z_operator, qubit_index);
    }

    // NEW: Implementation of the Pauli-Y gate
    void y(int qubit_index) {
        const std::complex<double> i(0.0, 1.0);
        matrix Y_operator = {{0, -i}, {i, 0}};
        applySingleQubitGate(Y_operator, qubit_index);
    }

    void cx(int control, int target) {
        int dim = 1 << no_of_qubits;
        matrix cx_mat = createIdentityMatrix(dim);

        for (int i = 0; i < dim; ++i) {
            std::string binary = basisState(i);
            int control_bit_pos = no_of_qubits - 1 - control;
            if (binary[control_bit_pos] == '1') {
                int target_bit_pos = no_of_qubits - 1 - target;
                std::string target_binary = binary;
                target_binary[target_bit_pos] = (target_binary[target_bit_pos] == '0' ? '1' : '0');
                int source_index = binaryToDecimal(binary);
                int target_index = binaryToDecimal(target_binary);
                if (source_index < target_index) {
                    std::swap(cx_mat[source_index], cx_mat[target_index]);
                }
            }
        }
        unitary = matMatMul(cx_mat, unitary);
    }

    // --- Simulation ---

    void run() {
        state_vector = matVecMul(unitary, state_vector);
    }

    std::vector<MeasurementResult> get_results(int the_number_of_shots = 1024) const {
        std::vector<MeasurementResult> results;
        int num_states = 1 << no_of_qubits;

        for (int i = 0; i < num_states; ++i) {
            // CHANGED: Use std::norm for complex amplitude probability calculation
            std::complex<double> amplitude = state_vector[i][0];
            double probability = std::norm(amplitude);
            int shots = static_cast<int>(round(probability * the_number_of_shots));
            
            results.push_back({basis[i], probability, shots});
        }
        return results;
    }

private:
    int no_of_qubits;
    // CHANGED: Member variables are now complex
    matrix unitary;
    vector_q state_vector;
    std::vector<std::string> basis;
    matrix I;
    vector_q zero_vector;

    // --- Helper Methods (updated for complex types) ---

    matrix matMatMul(const matrix& mat1, const matrix& mat2) const {
        if (mat1.empty() || mat2.empty() || mat1[0].empty() || mat2[0].empty()) return {};
        int r1 = mat1.size();
        int c1 = mat1[0].size();
        int r2 = mat2.size();
        int c2 = mat2[0].size();
        if (c1 != r2) return {};

        // CHANGED: Result matrix is complex
        matrix res(r1, std::vector<std::complex<double>>(c2, 0.0));
        for (int i = 0; i < r1; ++i) {
            for (int j = 0; j < c2; ++j) {
                for (int k = 0; k < c1; ++k) {
                    res[i][j] += mat1[i][k] * mat2[k][j];
                }
            }
        }
        return res;
    }

    vector_q matVecMul(const matrix& mat, const vector_q& vec) const {
        if (mat.empty() || vec.empty() || mat[0].empty()) return {};
        int mat_rows = mat.size();
        int mat_cols = mat[0].size();
        int vec_rows = vec.size();
        if (mat_cols != vec_rows) return {};

        // CHANGED: Result vector is complex
        vector_q result(mat_rows, std::vector<std::complex<double>>(1, 0.0));
        for (int i = 0; i < mat_rows; ++i) {
            for (int j = 0; j < mat_cols; ++j) {
                result[i][0] += mat[i][j] * vec[j][0];
            }
        }
        return result;
    }

    matrix tensorMatrix(const matrix& A, const matrix& B) const {
        if (A.empty() || B.empty() || A[0].empty() || B[0].empty()) return {};
        int row_a = A.size();
        int col_a = A[0].size();
        int row_b = B.size();
        int col_b = B[0].size();

        // CHANGED: Result matrix is complex
        matrix C(row_a * row_b, std::vector<std::complex<double>>(col_a * col_b, 0.0));
        for (int i = 0; i < row_a; ++i) {
            for (int j = 0; j < col_a; ++j) {
                for (int k = 0; k < row_b; ++k) {
                    for (int l = 0; l < col_b; ++l) {
                        C[i * row_b + k][j * col_b + l] = A[i][j] * B[k][l];
                    }
                }
            }
        }
        return C;
    }

    std::string basisState(int n) const {
        if (n == 0) return std::string(no_of_qubits, '0');
        std::string binary_str;
        while (n > 0) {
            binary_str = (n % 2 == 0 ? "0" : "1") + binary_str;
            n /= 2;
        }
        while (binary_str.length() < no_of_qubits) {
            binary_str = "0" + binary_str;
        }
        return binary_str;
    }
    
    int binaryToDecimal(const std::string& bin) const {
        return std::stoi(bin, nullptr, 2);
    }

    matrix createIdentityMatrix(int n) const {
        // CHANGED: Result matrix is complex
        matrix mat(n, std::vector<std::complex<double>>(n, 0.0));
        for (int i = 0; i < n; ++i) {
            mat[i][i] = 1.0;
        }
        return mat;
    }

    void applySingleQubitGate(const matrix& gate, int qubit_index) {
        // CHANGED: pdt matrix is complex
        matrix pdt = {{{1.0, 0.0}}};
        bool first = true;
        for (int i = no_of_qubits - 1; i >= 0; --i) {
            // This const_cast is not ideal but works for this specific structure.
            const matrix& current_op = (i == qubit_index) ? gate : I;
            if (first) {
                pdt = current_op;
                first = false;
            } else {
                pdt = tensorMatrix(pdt, current_op);
            }
        }
        unitary = matMatMul(pdt, unitary);
    }
};

#endif // QUANTUM_CIRCUIT_H